from distutils.core import setup

setup(
    name='StructStream',
    author_email='birm@rbirm.us',
    author='Ryan Birmingham',
    url="http://rbirm.us/struct-stream",
    version='a.dev',
    packages=['sstream'],
    license='none, to be added later',
    long_description=open('README.txt').read(),
)
