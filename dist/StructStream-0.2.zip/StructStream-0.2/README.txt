Structured Streams - Save stream xml or json information for easy usage, keep size under control, use key constraints, and summarize your data.
